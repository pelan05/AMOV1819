//
//  UCViewController.swift
//  ExamesISEC
//
//  Created by user149652 on 12/26/18.
//  Copyright © 2018 user149652. All rights reserved.
//

import UIKit

class UCViewController: UIViewController, UITextFieldDelegate, UINavigationControllerDelegate {
    

    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    @IBOutlet weak var cancel: UIBarButtonItem!
    
    @IBOutlet weak var ucTextField: UITextField!
    
    @IBOutlet weak var anoTextField: UITextField!
    
    @IBOutlet weak var semestreTextField: UITextField!
    
    @IBOutlet weak var normalDatePicker: UIDatePicker!
    
    @IBOutlet weak var recursoDatePicker: UIDatePicker!
    
    @IBOutlet weak var especialDatePicker: UIDatePicker!
    
    var uc: UC?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        ucTextField.delegate = self
        /*
        if let uc = uc{
            ucNameLabel.text = uc.name
            anoLabel = uc.ano
            semestreLabel = uc.semestre
            
        }*/
        
        updateSaveButtonState()
    }
    
    @IBAction func cancel(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        super.prepare(for: segue, sender: sender)
        guard let button = sender as? UIBarButtonItem, button === saveButton else {
            return
        }
        
        let name = ucTextField.text ?? ""
        let ano = anoTextField.text ?? ""
        let semestre = semestreTextField.text ?? ""
        let normal = normalDatePicker.date
        let recurso = recursoDatePicker.date
        let especial = especialDatePicker.date
        
        uc = UC(name: name, ano: ano, semestre: semestre, normal: normal, recurso: recurso, especial: especial)
        

        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        saveButton.isEnabled = false
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
        navigationItem.title = textField.text
    }
    
    private func updateSaveButtonState (){
        let text = ucTextField.text ?? ""
        saveButton.isEnabled = !text.isEmpty
    }


}

