//
//  UC.swift
//  ExamesISEC
//
//  Created by user149652 on 12/26/18.
//  Copyright © 2018 user149652. All rights reserved.
//

import UIKit


class UC: NSObject, NSCoding {
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: PropertyKey.nome)
        aCoder.encode(ano, forKey: PropertyKey.ano)
        aCoder.encode(semestre, forKey: PropertyKey.semestre)
        aCoder.encode(normal, forKey: PropertyKey.norm)
        aCoder.encode(recurso, forKey: PropertyKey.rec)
        aCoder.encode(especial, forKey: PropertyKey.esp)
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        guard let name = aDecoder.decodeObject(forKey: PropertyKey.nome) as? String else {
            return nil
        }
        
        guard let ano = aDecoder.decodeObject(forKey: PropertyKey.ano) as? String else {
            return nil
        }
        
        guard let semestre = aDecoder.decodeObject(forKey: PropertyKey.semestre) as? String else {
            return nil
        }
        
        guard let normal = aDecoder.decodeObject(forKey: PropertyKey.norm) as? Date else {
            return nil
        }
        
        guard let rec = aDecoder.decodeObject(forKey: PropertyKey.rec) as? Date else {
            return nil
        }
        
        guard let esp = aDecoder.decodeObject(forKey: PropertyKey.esp) as? Date else {
            return nil
        }
        
        self.init(name: name, ano: ano, semestre: semestre, normal: normal, recurso: rec, especial: esp)
        
    }
    
    
    struct PropertyKey{
        static let nome = "nome"
        static let ano = "ano"
        static let semestre = "semestre"
        static let norm = "norm"
        static let rec = "rec"
        static let esp = "esp"
    }
    
    var name: String
    var ano: String
    var semestre: String
    var normal: Date
    var recurso: Date
    var especial: Date
    
    init?(name: String, ano: String, semestre: String, normal: Date, recurso: Date, especial: Date) {
        
        guard !name.isEmpty else{
            return nil
        }
        
        guard !ano.isEmpty else{
            return nil
        }
        
        guard !semestre.isEmpty else{
            return nil
        }
        
        if recurso < normal{
            return nil
        }
        
        if especial < recurso{
            return nil
        }
        
        if ano != "1" || ano != "2" || ano != "3" {
            return nil
        }
        
        if semestre != "1" || semestre != "2" {
            return nil
        }
        
        self.name = name
        self.ano = ano
        self.semestre = semestre
        self.normal = normal
        self.recurso = recurso
        self.especial = especial
    }
    
    static let DocDir = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchURL = DocDir.appendingPathComponent("ucs")
}
