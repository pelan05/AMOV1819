//
//  UCTableViewCell.swift
//  ExamesISEC
//
//  Created by user149652 on 12/26/18.
//  Copyright © 2018 user149652. All rights reserved.
//

import UIKit

class UCTableViewCell: UITableViewCell {
    
    @IBOutlet weak var ucNameLabel: UILabel!
    
    @IBOutlet weak var anoLabel: UILabel!
    
    @IBOutlet weak var semestreLabel: UILabel!
    
    @IBOutlet weak var normalLabel: UILabel!
    
    @IBOutlet weak var recursoLabel: UILabel!
    
    @IBOutlet weak var especialLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
