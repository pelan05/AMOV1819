//
//  UCTableViewController.swift
//  ExamesISEC
//
//  Created by user149652 on 12/26/18.
//  Copyright © 2018 user149652. All rights reserved.
//

import UIKit
import os.log

class UCTableViewController: UITableViewController {
    
    var UCs = [UC]()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.leftBarButtonItem = editButtonItem

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        
        if let savedUCs = loadUCs(){
            UCs += savedUCs
        } else {
            loadSample()
        }
            
   
            
    }
    
    private func loadSample(){
        
        
        
        
        guard let uc = UC(name: "Yes", ano: "1", semestre: "1", normal: Date(), recurso: Date.init(timeIntervalSinceNow: 3600), especial: Date.init(timeIntervalSinceNow: 7200)) else{
            fatalError("Yes")
        }
        
        UCs += [uc]
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1 // should be done
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return UCs.count
    }
    
    @IBAction func unwindToUCList(sender: UIStoryboardSegue){
        if let sourceViewController = sender.source as? UCViewController, let uc = sourceViewController.uc {
            let newIndexPath = IndexPath(row: UCs.count, section: 0)
            
            UCs.append(uc)
            tableView.insertRows(at: [newIndexPath], with: .automatic)
        }
        
        saveUCs()
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "UCTableViewCell"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? UCTableViewCell else{
            fatalError("fail instancing")
        }
        
        let uc = UCs[indexPath.row]
        
        cell.ucNameLabel.text = uc.name
        cell.anoLabel.text = uc.ano
        cell.semestreLabel.text = uc.semestre
        
        let dateformatter1 = DateFormatter()
        let dateValue1 = dateformatter1.string(from: uc.normal)
        cell.normalLabel.text = dateValue1
        
        let dateformatter2 = DateFormatter()
        let dateValue2 = dateformatter2.string(from: uc.recurso)
        cell.recursoLabel.text = dateValue2
        
        let dateformatter3 = DateFormatter()
        let dateValue3 = dateformatter3.string(from: uc.recurso)
        cell.especialLabel.text = dateValue3

        // Configure the cell...

        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            UCs.remove(at: indexPath.row)
            saveUCs()
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        super.prepare(for: segue, sender: sender)
        
        switch(segue.identifier ?? ""){
        case "AddItem":
            os_log("AddingItem", log: OSLog.default, type: .debug)
        case "ShowDetail":
            guard let UCDetailViewController = segue.destination as? UCViewController else{
                fatalError("bad destination")
            }
            
            guard let selectedUCCell = sender as? UCTableViewCell else{
                fatalError("cenas destination")
            }
            
            guard let indexPath = tableView.indexPath(for: selectedUCCell) else{
                fatalError("cenas na table")
            }
            
            let selectedUC = UCs[indexPath.row]
            UCDetailViewController.uc = selectedUC
            
        default:
            fatalError("bad segue ")
        }
    }
    
    private func saveUCs(){
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(UCs, toFile: UC.ArchURL.path)
        
    }
    
    private func loadUCs() -> [UC]?{
        return NSKeyedUnarchiver.unarchiveObject(withFile: UC.ArchURL.path) as? [UC]
    }
 

}
